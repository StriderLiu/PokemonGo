package datecleaning.Poke

import org.apache.parquet.filter2.predicate.Operators.Column
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Created by Shuxian on 12/6/16.
  */
object Poke extends App{

  val logFile = "/Users/Shuxian/Documents/Scala/PikaPika/log" // Should be some file on your system
  val conf = new SparkConf().setAppName("Poke_DataCleaning").setMaster("local")
  val sc = new SparkContext(conf)

  val dir = "/Users/Shuxian/Documents/CSYE7200-Fall2016/predictemall/"
  val poke = sc.textFile(dir+"300k.csv").map(line => line.split(",").map(_.trim))

  //
  val headers=poke.first()
  val data=poke.filter(_(0) != headers(0)).filter(line=>line(49) !="?")

  println(data.count()) //295982
  println(headers(0))  //pokemonId

  val colsToRemove = Seq("pokemonId", "appearedLocalTime", "_id", "cellId_90m", "cellId_180m",
    "cellId_370m", "cellId_730m", "cellId_1460m", "cellId_2920m", "cellId_5850m", "weatherIcon")


}
