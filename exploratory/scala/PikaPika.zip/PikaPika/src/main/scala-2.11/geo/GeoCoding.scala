package geo

/**
  * Created by Shuxian on 12/6/16.
  */

import geo.Pokemons.Coordinate
import play.api.libs.json.{JsValue, Json}

import scala.io.Source.fromURL

object GeoCoding extends App{

  def toJson(url: String): JsValue = Json.parse(fromURL(url).mkString)

  val key = "AIzaSyDXxUKKAooWrPYxk09yudhZCKVw5zTWYlw"

//  val url=s"https://maps.googleapis.com/maps/api/geocode/json?address=Queensberry+St,+Boston,+MA+02215&key=${key}"
//
//  val url1=s"https://maps.googleapis.com/maps/api/geocode/json?address=1111+S+Figueroa+St,+Los_Angeles,+CA+90015,+USA&key=AIzaSyDXxUKKAooWrPYxk09yudhZCKVw5zTWYlw"
  def getCoordianate(address: String,key:String)={
    val url=s"https://maps.googleapis.com/maps/api/geocode/json?address=${address}&key=${key}"
    val coord=((toJson(url)\"results" )(0)\"geometry" \ "location")
    Coordinate((coord \ "lat").as[Double],(coord \ "lng").as[Double])
  }

  val input = "5th avenue, new york"
  val s=input.split(", ")
  val street:String=s(0).replace(" ","+")
  val city:String=s(1).replace(" ","+")
  val address=street+",+"+city
//  val address = for {
//        s <- input.split(",")
//        street = s(0).toString().replace(" ", "+")
//        city = s(1).toString().replace(" ", "+")
//        add=street+",+"+city
//      } yield add
  println(address)


//  val jsValue=toJson(url1)
////  println(jsValue)
//  val coord=((jsValue\"results" )(0)\"geometry" \ "location").get
//  val lat=(coord \ "lat").as[Double]
//
//  val lng = (coord \ "lng").as[Double]
//
////  val pid=(jsValue\"results" \"place_id").get.as[String]
//  println(Coordinate(lat,lng))

}
